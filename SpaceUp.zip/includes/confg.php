<?php
// Database configuration
define('DB_HOST', 'sql101.infinityfree.com');
define('DB_NAME', 'if0_40178069_school');
define('DB_USER', 'if0_40178069');
define('DB_PASS', 'OaDWhDeh1j');

// Site configuration
define('SITE_NAME', 'SpaceUp');
define('SITE_URL', 'https://spaceup.great-site.net');

// Start session
session_start();

// Database connection
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>